function mostrar()
{
var cantidad;
var precio;
var tarjeta;
var descuento;
cantidad = prompt("cantidad");
precio = prompt("precio");
tarjeta = confirm("tarjeta");
cantidad = parseInt(cantidad);
precio = parseInt(precio);
if(cantidad > 2){
    descuento = 0.1;
}
if(precio > 2000){
    descuento
}
}
