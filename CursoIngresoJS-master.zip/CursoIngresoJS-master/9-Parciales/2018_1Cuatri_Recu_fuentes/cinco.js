function mostrar()
{
var cantidad;
var precio;
var tarjeta;
cantidad = prompt("cantidad");
precio = prompt("precio");
tarjeta = confirm("tarjeta");
cantidad = parseInt(cantidad);
precio = parseInt(precio);
}
