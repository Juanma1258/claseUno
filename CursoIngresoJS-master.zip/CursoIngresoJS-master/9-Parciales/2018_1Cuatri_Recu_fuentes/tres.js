function mostrar()
{
var gasto;
var propina;
var cantidadDeAmigos;
gasto = prompt("gastaron");
cantidadDeAmigos = prompt("cantidad de amigos");
propina = prompt("dejaron de propina");
gasto = parseInt(gasto);


}
