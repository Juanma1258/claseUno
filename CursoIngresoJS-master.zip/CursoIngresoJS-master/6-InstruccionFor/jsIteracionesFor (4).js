function mostrar()
{




}//FIN DE LA FUNCIÓN