function mostrar()
{
var cont = 0;

while(cont <  10){
	cont ++;
	console.log(cont);
}

}//FIN DE LA FUNCIÓN
