function mostrar()
{
	var cont = 11;
	while(cont > 0){
    cont --;
		console.log(cont);
	}


}//FIN DE LA FUNCIÓN
