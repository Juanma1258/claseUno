function mostrar()
{

	var suma;
  var num 
  var cont = 0;


document.getElementById('suma').value= suma;
while(cont < 5){
  cont ++;
  num = prompt("ingrese un numero");
  num = parseInt(num);
  suma += num;
}
}//FIN DE LA FUNCIÓN
