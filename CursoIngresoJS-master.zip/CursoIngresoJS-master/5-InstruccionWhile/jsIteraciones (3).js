function mostrar()
{

var clave = prompt("ingrese el número clave.");

while(clave != "utn750"){
    clave = prompt("error");


}


}//FIN DE LA FUNCIÓN
