function mostrar()
{
  var num;
  var sumNeg;
  var contNeg = 0;
  num = prompt("ingrese el num");
  num = parseInt(num);
  while( isNaN(num));
  if(num < 0){
  sumNeg += num;
  contNeg ++;
  } else{

  }
}//FIN DE LA FUNCIÓN
