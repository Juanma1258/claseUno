function mostrar()
{

var contador=0;
var acumulador=0;
var respuesta="si";

document.getElementById('suma').value=acumulador;
document.getElementById('promedio').value=acumulador/contador;


} //FIN DE LA FUNCIÓN
