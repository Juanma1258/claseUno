//Debemos lograr mostrar un mensaje al presionar el botón  'mostrar'.
function mostrar()
{
	alert("hola");
	}

