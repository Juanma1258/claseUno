function mostrar()
{
//tomo la edad  
var laHora = document.getElementById('hora').value;



}//FIN DE LA FUNCIÓN