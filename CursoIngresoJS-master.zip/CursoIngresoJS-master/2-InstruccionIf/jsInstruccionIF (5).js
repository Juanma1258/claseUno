function mostrar()
{
//tomo la edad  
var edad;
edad = document.getElementById("edad").value;
if(edad < 13 || edad > 17){
    if(edad == true){

    }
    alert("no eres un adolescente");
}

}//FIN DE LA FUNCIÓN