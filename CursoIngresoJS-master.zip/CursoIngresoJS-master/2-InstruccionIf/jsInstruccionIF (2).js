function mostrar()
{
//tomo la edad  
var edad;
edad = document.getElementById("edad").value;
if(edad >= 18) {
    if(edad == true){
    }
    alert("eres mayor de edad");
}
}//FIN DE LA FUNCIÓN