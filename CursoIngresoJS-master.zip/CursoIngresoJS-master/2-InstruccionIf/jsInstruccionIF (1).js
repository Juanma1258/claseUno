function mostrar()
{
//tomo la edad  
var edad;
edad = document.getElementById("edad").value;
if(edad == 15) {
    if(edad == true) {
        
    }
    alert("niña bonita");
}
}//FIN DE LA FUNCIÓN