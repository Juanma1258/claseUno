function mostrar()
{
	//Genero el número RANDOM entre 1 y 10 
	var numero;
	numero = parseInt(Math.random()*10 + 1);
	alert("el numero es " + numero);

}//FIN DE LA FUNCIÓN